public class Main {
    public static void main(String[] args) {
        ctrl ctrl1= new ctrl();
        ctrl1.start();
    }
}
